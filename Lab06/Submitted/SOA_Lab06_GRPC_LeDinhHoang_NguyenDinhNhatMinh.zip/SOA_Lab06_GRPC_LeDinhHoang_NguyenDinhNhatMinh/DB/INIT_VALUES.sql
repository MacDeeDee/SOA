use SOA;

insert into personalInfo
	value ("17021254", "Lê Đình Hoàng", "Nam", "1999-09-10");
    
insert into email
	value ("17021254", "17021254@vnu.edu.vn");
    
insert into email
	value ("17021254", "thl9x9@gmail.com");
    
insert into relative
	value ("17021254", "Mom", "Nguyễn Thị Nga", "Số 36, phố Văn Cao, Hà Nội");

insert into relative
	value ("17021254", "Dad", "Lê Văn A", "Số 30, phố Văn Cao, Hà Nội");
    
insert into personalInfo
	value ("17021298", "Nguyễn Đình Nhật Minh ", "Nam", "1999-09-23");
    
insert into email
	value ("17021298", "17021298@vnu.edu.vn");
    
insert into relative
	value ("17021298", "Dad", "Nguyễn Văn A", "Số 130, phố Cầu Giấy, Hà Nội");

insert into personalInfo
	value ("18021350", "Lê Văn D", "Nam", "2000-05-11");
    
insert into email
	value ("18021350", "18021350@vnu.edu.vn");
    
insert into relative
	value ("18021350", "Mom", "Nguyễn Thị C", "Số 40, phố Núi Trúc, Hà Nội");
    